import { useState, useEffect } from "react";
import { fetchStudentByIdAPI, fetchStudentPerformanceAPI, updateStudentAPI } from "./API";


export interface Student {
  _id: string;
  user_id: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  dob: Date;
  address: string;
  city: string;
  state: string;
  district: string;
  adm_no: string;
  reg_no: string;
  gender: string;
  email: string;
  alt_email: string;
  ph_no: string;
  alt_ph: string;
  join_date: string;
  end_date: Date;  
  program: string;
  status: string;
}

export interface FileInfo {
  filename: string;
  filepath: string;
}

export interface Performance {
  _id: string;
  student_id: string;
  semester: number;
  tenth_cgpa: number;
  twelfth_cgpa: number;
  mca_cgpa: number[];
  certification_files: FileInfo[]; // Updated to use FileInfo[]
  job_application_files: FileInfo[]; // Updated to use FileInfo[]
  skills: string[];
  current_status: string;
  year: number;
  mca_percentage: number;
  linkedin_url: string;
}

export const useStudentManagement = () => {
  const [user_id, setUserId] = useState("");
  const [student, setStudent] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<any>(null);
  const [performance, setPerformance] = useState({});
  const [performanceLoading, setPerformanceLoading] = useState(false);
  const [performanceError, setPerformanceError] = useState(null);
  const [studentForm, setStudentForm] = useState({
    first_name: "",
    middle_name: "",
    last_name: "",
    email: "",
    alt_email: "",
    ph_no: "",
    alt_ph: "",
    address: "",
    city: "",
    state: "",
    district: "",
  })

  const [performanceForm, setPerformanceForm] = useState({

    skills: [] as string[],
    current_status: "",
    linkedin_url: "",

  });

  useEffect(() => {
    if (student) {
      setStudentForm({
        first_name: (student as Student).first_name || "",
        middle_name: (student as Student).middle_name || "",
        last_name: (student as Student).last_name || "",
        email: (student as Student).email || "",
        alt_email: (student as Student).alt_email || "",
        ph_no: (student as Student).ph_no || "",
        alt_ph: (student as Student).alt_ph || "",
        address: (student as Student).address || "",
        city: (student as Student).city || "",
        state: (student as Student).state || "",
        district: (student as Student).district || "",
      });
    }
  }, [student]);

  useEffect(() => {
    if (performance) {
      setPerformanceForm({
        skills: (performance as Performance).skills || [],
        current_status: (performance as Performance).current_status || "",
        linkedin_url: (performance as Performance).linkedin_url || "",
      });
    }
  }, [performance]);

  

  const handleStudentFormChange = (field:string, value:any) => {
    setStudentForm(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePerformanceFormChange = (field:string, value:any) => {
    setPerformanceForm(prev => ({
      ...prev,
      [field]: value
    }));
  };




  const handlefetchStudent = async (userid: any) => {
    if(userid !== user_id) {
      setUserId(userid);
    }
    try{
        const response = await fetchStudentByIdAPI(userid);
        setStudent(response);
        handleFetchPerformance(response._id);
    }
    catch(error){
        console.error(`Error in fetching student data: ${error}`);
        setError(error);
    }
};

const handleFetchPerformance = async (student_id: any) => {
  setPerformanceLoading(true);
  setPerformanceError(null);
  try {
      const response = await fetchStudentPerformanceAPI(student_id);
      setPerformance(response);
  } catch (error: any) {
      setPerformanceError(error.message);
      console.error(`Error in fetching student performance: ${error}`);
  } finally {
      setPerformanceLoading(false);
  }
};

// ...existing code...

const handleEditStudent = async (student: Student) => {
  try {
    const updateData = {
      first_name: studentForm.first_name || student.first_name,
      middle_name: studentForm.middle_name || student.middle_name,
      last_name: studentForm.last_name || student.last_name,
      address: studentForm.address || student.address,
      city: studentForm.city || student.city,
      state: studentForm.state || student.state,
      district: studentForm.district || student.district,
      email: studentForm.email || student.email,
      alt_email: studentForm.alt_email || student.alt_email,
      ph_no: studentForm.ph_no || student.ph_no,
      alt_ph: studentForm.alt_ph || student.alt_ph,
    };
    
    const response = await updateStudentAPI(student._id, updateData);
    setStudent(response);
  } catch (error) {
    console.error(`Error in updating student name: ${error}`);
    setError(error);
  }
};


const handleFileUpload = async (
  files: FileList, 
  type: string, 
  studentId: string,
  onProgress?: (progress: number) => void
) => {
  try {
    const formData = new FormData();
    
    Array.from(files).forEach((file) => {
      formData.append('files', file);
    });
    
    formData.append('type', type);
    formData.append('student_id', studentId);

    // Use XMLHttpRequest for progress tracking
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      
      if (onProgress) {
        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const progress = Math.round((event.loaded * 100) / event.total);
            onProgress(progress);
          }
        };
      }

      xhr.onload = async () => {
        if (xhr.status === 200) {
          // Refresh student performance data after upload
        await handleFetchPerformance(studentId);
          resolve(xhr.response);
        } else {
          reject(new Error('Upload failed'));
        }
      };

      xhr.onerror = () => {
        reject(new Error('Network error'));
      };

      xhr.open('POST', `${process.env.NEXT_PUBLIC_API_BASE_URL}/student-performance/upload-documents`);
      xhr.send(formData);
    });
  } catch (error) {
    console.error('Error uploading files:', error);
    throw error;
  }
};

const handleDeleteDocument = async (filepath: string, type: string) => {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/student-performance/documents`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        filepath,
        type,
        student_id: (student as Student)._id
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to delete document');
    }

    // Refresh performance data after deletion
    await handleFetchPerformance((student as Student)._id);
  } catch (error) {
    console.error('Error deleting document:', error);
    throw error;
  }
};


useEffect(() => {
        console.log(performance);
    }, [performance]);

  return {
    student, setStudent,
    studentForm,
    setStudentForm,
    performanceForm,
    setPerformanceForm,
    handlefetchStudent,
    loading, setLoading,
    error, setError,
    performance, setPerformance,
    performanceLoading,
    performanceError,
    handleFetchPerformance,
    handleEditStudent,
    handleStudentFormChange,
    handlePerformanceFormChange,
    handleFileUpload,
    handleDeleteDocument
  };

}
