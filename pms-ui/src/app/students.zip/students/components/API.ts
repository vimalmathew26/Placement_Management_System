import { Student } from "./useStudentManagement"

export const fetchStudentByIdAPI = async (userId: any) => {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/student/get-user/${userId}`, {
        method: "GET",
    });
    if (!response.ok) {
        throw new Error(`Server returned with an error: ${response.status}`);
    }
    return await response.json();
}


export const fetchStudentPerformanceAPI = async (student_id: string) => {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/student-performance/get/${student_id}`, {
            method: 'GET',
        });

        if (!response.ok) {
            throw new Error('Failed to fetch student performance');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching student performance:', error);
        throw error;
    }
};


export const updateStudentAPI = async (id: string, updatedData: Partial<Student>) => {
    try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/student/update/${id}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedData),
        });

        if (!response.ok) {
            throw new Error('Failed to update student');
        }

        return await response.json();
    }
    catch (error) {
        console.error('Error updating student:', error);
        throw error;
    }
}