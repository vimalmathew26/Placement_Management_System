import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter, Button } from "@heroui/react";
import PDFViewer from "./PDFViewer";

interface PDFPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  fileUrl: string;
  fileName: string;
}

export default function PDFPreviewModal({ isOpen, onClose, fileUrl, fileName }: PDFPreviewModalProps) {
  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose}
      size="4xl"
    >
      <ModalContent>
        <ModalHeader>{fileName}</ModalHeader>
        <ModalBody>
          <div className="h-[70vh]">
            <PDFViewer fileUrl={fileUrl} fileName={fileName} />
          </div>
        </ModalBody>
        <ModalFooter>
          <Button color="danger" variant="light" onPress={onClose}>
            Close
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}